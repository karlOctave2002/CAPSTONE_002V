--
-- PostgreSQL database dump
--

\restrict ta0nctkbuy5Du9igA8k5GZ9h0t8GLFtlvrT3S7SIWCC2ImnCOOiYcnUiUcwLJKh

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.7

-- Started on 2026-11-21 01:32:53

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 5 (class 2615 OID 2200)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 219 (class 1259 OID 16406)
-- Name: alerta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerta (
    id_alerta integer NOT NULL,
    id_adulto_mayor integer NOT NULL,
    id_estado_actual integer NOT NULL,
    id_responsable_atencion integer,
    id_operador_asignado integer,
    tipo_activacion character varying(30) NOT NULL,
    fecha_creacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_atencion timestamp without time zone,
    fecha_cierre timestamp without time zone,
    observacion_cierre text,
    intervalo_escalamiento_minutos integer
);


--
-- TOC entry 220 (class 1259 OID 16417)
-- Name: alerta_id_alerta_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.alerta ALTER COLUMN id_alerta ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.alerta_id_alerta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 221 (class 1259 OID 16418)
-- Name: auditoria; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auditoria (
    id_auditoria integer NOT NULL,
    id_usuario integer,
    entidad character varying(100) NOT NULL,
    id_registro integer,
    accion character varying(100) NOT NULL,
    detalle text,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 16428)
-- Name: auditoria_id_auditoria_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auditoria ALTER COLUMN id_auditoria ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.auditoria_id_auditoria_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 223 (class 1259 OID 16429)
-- Name: estadoalerta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.estadoalerta (
    id_estado integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(255),
    orden integer,
    es_final boolean DEFAULT false NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 16437)
-- Name: estadoalerta_id_estado_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.estadoalerta ALTER COLUMN id_estado ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.estadoalerta_id_estado_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 249 (class 1259 OID 16737)
-- Name: flyway_schema_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flyway_schema_history (
    installed_rank integer NOT NULL,
    version character varying(50),
    description character varying(200) NOT NULL,
    type character varying(20) NOT NULL,
    script character varying(1000) NOT NULL,
    checksum integer,
    installed_by character varying(100) NOT NULL,
    installed_on timestamp without time zone DEFAULT now() NOT NULL,
    execution_time integer NOT NULL,
    success boolean NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 16438)
-- Name: historialalerta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historialalerta (
    id_historial integer NOT NULL,
    id_alerta integer NOT NULL,
    id_usuario_actor integer,
    id_estado_anterior integer,
    id_estado_nuevo integer,
    accion character varying(100) NOT NULL,
    observacion text,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 16448)
-- Name: historialalerta_id_historial_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.historialalerta ALTER COLUMN id_historial ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.historialalerta_id_historial_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 248 (class 1259 OID 16709)
-- Name: mensajealerta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mensajealerta (
    id_mensaje integer NOT NULL,
    id_alerta integer NOT NULL,
    id_autor integer NOT NULL,
    texto character varying(2000) NOT NULL,
    clave uuid NOT NULL,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT ck_mensajealerta_texto CHECK ((length(btrim((texto)::text)) > 0))
);


--
-- TOC entry 247 (class 1259 OID 16708)
-- Name: mensajealerta_id_mensaje_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.mensajealerta ALTER COLUMN id_mensaje ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.mensajealerta_id_mensaje_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 227 (class 1259 OID 16449)
-- Name: notificacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notificacion (
    id_notificacion integer NOT NULL,
    id_alerta integer NOT NULL,
    id_destinatario integer NOT NULL,
    numero_intento integer NOT NULL,
    canal character varying(30) NOT NULL,
    estado_envio character varying(30) NOT NULL,
    fecha_programada timestamp without time zone,
    fecha_envio timestamp without time zone,
    resultado text,
    fecha_inicio_proceso timestamp without time zone,
    tipo_aviso character varying(30)
);


--
-- TOC entry 228 (class 1259 OID 16460)
-- Name: notificacion_id_notificacion_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.notificacion ALTER COLUMN id_notificacion ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.notificacion_id_notificacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 229 (class 1259 OID 16461)
-- Name: parametrosistema; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parametrosistema (
    id_parametro integer NOT NULL,
    clave character varying(100) NOT NULL,
    valor text NOT NULL,
    tipo_dato character varying(30) NOT NULL,
    descripcion text,
    id_usuario_actualiza integer,
    fecha_actualizacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 16472)
-- Name: parametrosistema_id_parametro_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.parametrosistema ALTER COLUMN id_parametro ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.parametrosistema_id_parametro_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 231 (class 1259 OID 16473)
-- Name: permiso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permiso (
    id_permiso integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(255)
);


--
-- TOC entry 232 (class 1259 OID 16479)
-- Name: permiso_id_permiso_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.permiso ALTER COLUMN id_permiso ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.permiso_id_permiso_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 251 (class 1259 OID 16755)
-- Name: recuperacion_clave; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recuperacion_clave (
    id_recuperacion integer NOT NULL,
    id_usuario integer NOT NULL,
    codigo_hash character varying(100) NOT NULL,
    fecha_creacion timestamp without time zone NOT NULL,
    fecha_expiracion timestamp without time zone NOT NULL,
    intentos integer DEFAULT 0 NOT NULL,
    usado boolean DEFAULT false NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 16754)
-- Name: recuperacion_clave_id_recuperacion_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.recuperacion_clave ALTER COLUMN id_recuperacion ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.recuperacion_clave_id_recuperacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 233 (class 1259 OID 16480)
-- Name: redapoyo; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.redapoyo (
    id_red_apoyo integer NOT NULL,
    id_adulto_mayor integer NOT NULL,
    id_integrante integer NOT NULL,
    prioridad integer NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    fecha_asociacion timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 16491)
-- Name: redapoyo_id_red_apoyo_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.redapoyo ALTER COLUMN id_red_apoyo ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.redapoyo_id_red_apoyo_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 235 (class 1259 OID 16492)
-- Name: respuestaalerta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.respuestaalerta (
    id_respuesta integer NOT NULL,
    id_alerta integer NOT NULL,
    id_integrante integer NOT NULL,
    tipo_respuesta character varying(50) NOT NULL,
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    observacion text
);


--
-- TOC entry 236 (class 1259 OID 16503)
-- Name: respuestaalerta_id_respuesta_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.respuestaalerta ALTER COLUMN id_respuesta ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.respuestaalerta_id_respuesta_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 237 (class 1259 OID 16504)
-- Name: rol; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rol (
    id_rol integer NOT NULL,
    codigo character varying(50) NOT NULL,
    nombre character varying(100) NOT NULL,
    descripcion character varying(255),
    estado boolean DEFAULT true NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 16512)
-- Name: rol_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rol ALTER COLUMN id_rol ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rol_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 239 (class 1259 OID 16513)
-- Name: rolpermiso; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rolpermiso (
    id_rol_permiso integer NOT NULL,
    id_rol integer NOT NULL,
    id_permiso integer NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 16519)
-- Name: rolpermiso_id_rol_permiso_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.rolpermiso ALTER COLUMN id_rol_permiso ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rolpermiso_id_rol_permiso_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 241 (class 1259 OID 16520)
-- Name: solicitudvinculacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.solicitudvinculacion (
    id_solicitud integer NOT NULL,
    id_adulto_mayor integer NOT NULL,
    id_asistente integer NOT NULL,
    estado character varying(15) DEFAULT 'PENDIENTE'::character varying NOT NULL,
    fecha_solicitud timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    fecha_respuesta timestamp without time zone,
    CONSTRAINT chk_solicitud_estado CHECK (((estado)::text = ANY (ARRAY[('PENDIENTE'::character varying)::text, ('APROBADA'::character varying)::text, ('RECHAZADA'::character varying)::text]))),
    CONSTRAINT chk_solicitud_usuarios_distintos CHECK ((id_adulto_mayor <> id_asistente))
);


--
-- TOC entry 242 (class 1259 OID 16532)
-- Name: solicitudvinculacion_id_solicitud_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.solicitudvinculacion ALTER COLUMN id_solicitud ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.solicitudvinculacion_id_solicitud_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 243 (class 1259 OID 16533)
-- Name: ubicacion; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ubicacion (
    id_ubicacion integer NOT NULL,
    id_alerta integer NOT NULL,
    latitud numeric(9,6) NOT NULL,
    longitud numeric(9,6) NOT NULL,
    precision_metros numeric(8,2),
    fecha_hora timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 16542)
-- Name: ubicacion_id_ubicacion_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.ubicacion ALTER COLUMN id_ubicacion ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.ubicacion_id_ubicacion_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 245 (class 1259 OID 16543)
-- Name: usuario; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.usuario (
    id_usuario integer NOT NULL,
    id_rol integer NOT NULL,
    nombre_apellido character varying(150) NOT NULL,
    correo character varying(150) NOT NULL,
    telefono character varying(30),
    password_hash text NOT NULL,
    token_fcm text,
    frase_activacion character varying(100),
    voz_activa boolean DEFAULT false NOT NULL,
    estado boolean DEFAULT true NOT NULL,
    codigo_vinculacion character varying(20)
);


--
-- TOC entry 246 (class 1259 OID 16557)
-- Name: usuario_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.usuario ALTER COLUMN id_usuario ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.usuario_id_usuario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3330 (class 2606 OID 16559)
-- Name: alerta alerta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerta
    ADD CONSTRAINT alerta_pkey PRIMARY KEY (id_alerta);


--
-- TOC entry 3332 (class 2606 OID 16561)
-- Name: auditoria auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT auditoria_pkey PRIMARY KEY (id_auditoria);


--
-- TOC entry 3334 (class 2606 OID 16563)
-- Name: estadoalerta estadoalerta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.estadoalerta
    ADD CONSTRAINT estadoalerta_pkey PRIMARY KEY (id_estado);


--
-- TOC entry 3372 (class 2606 OID 16752)
-- Name: flyway_schema_history flyway_schema_history_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flyway_schema_history
    ADD CONSTRAINT flyway_schema_history_pk PRIMARY KEY (installed_rank);


--
-- TOC entry 3336 (class 2606 OID 16565)
-- Name: historialalerta historialalerta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historialalerta
    ADD CONSTRAINT historialalerta_pkey PRIMARY KEY (id_historial);


--
-- TOC entry 3368 (class 2606 OID 16723)
-- Name: mensajealerta mensajealerta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensajealerta
    ADD CONSTRAINT mensajealerta_pkey PRIMARY KEY (id_mensaje);


--
-- TOC entry 3338 (class 2606 OID 16568)
-- Name: notificacion notificacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT notificacion_pkey PRIMARY KEY (id_notificacion);


--
-- TOC entry 3340 (class 2606 OID 16570)
-- Name: parametrosistema parametrosistema_clave_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametrosistema
    ADD CONSTRAINT parametrosistema_clave_key UNIQUE (clave);


--
-- TOC entry 3342 (class 2606 OID 16572)
-- Name: parametrosistema parametrosistema_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametrosistema
    ADD CONSTRAINT parametrosistema_pkey PRIMARY KEY (id_parametro);


--
-- TOC entry 3344 (class 2606 OID 16574)
-- Name: permiso permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permiso
    ADD CONSTRAINT permiso_pkey PRIMARY KEY (id_permiso);


--
-- TOC entry 3376 (class 2606 OID 16768)
-- Name: recuperacion_clave recuperacion_clave_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recuperacion_clave
    ADD CONSTRAINT recuperacion_clave_pkey PRIMARY KEY (id_recuperacion);


--
-- TOC entry 3346 (class 2606 OID 16576)
-- Name: redapoyo redapoyo_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redapoyo
    ADD CONSTRAINT redapoyo_pkey PRIMARY KEY (id_red_apoyo);


--
-- TOC entry 3348 (class 2606 OID 16578)
-- Name: respuestaalerta respuestaalerta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.respuestaalerta
    ADD CONSTRAINT respuestaalerta_pkey PRIMARY KEY (id_respuesta);


--
-- TOC entry 3350 (class 2606 OID 16580)
-- Name: rol rol_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rol
    ADD CONSTRAINT rol_pkey PRIMARY KEY (id_rol);


--
-- TOC entry 3352 (class 2606 OID 16582)
-- Name: rolpermiso rolpermiso_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolpermiso
    ADD CONSTRAINT rolpermiso_pkey PRIMARY KEY (id_rol_permiso);


--
-- TOC entry 3356 (class 2606 OID 16584)
-- Name: solicitudvinculacion solicitudvinculacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solicitudvinculacion
    ADD CONSTRAINT solicitudvinculacion_pkey PRIMARY KEY (id_solicitud);


--
-- TOC entry 3360 (class 2606 OID 16588)
-- Name: ubicacion ubicacion_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT ubicacion_pkey PRIMARY KEY (id_ubicacion);


--
-- TOC entry 3370 (class 2606 OID 16725)
-- Name: mensajealerta uq_mensajealerta_reintento; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensajealerta
    ADD CONSTRAINT uq_mensajealerta_reintento UNIQUE (id_alerta, id_autor, clave);


--
-- TOC entry 3354 (class 2606 OID 16590)
-- Name: rolpermiso uq_rol_permiso; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolpermiso
    ADD CONSTRAINT uq_rol_permiso UNIQUE (id_rol, id_permiso);


--
-- TOC entry 3363 (class 2606 OID 16592)
-- Name: usuario usuario_correo_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_correo_key UNIQUE (correo);


--
-- TOC entry 3365 (class 2606 OID 16594)
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (id_usuario);


--
-- TOC entry 3373 (class 1259 OID 16753)
-- Name: flyway_schema_history_s_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX flyway_schema_history_s_idx ON public.flyway_schema_history USING btree (success);


--
-- TOC entry 3366 (class 1259 OID 16736)
-- Name: idx_mensajealerta_conversacion; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mensajealerta_conversacion ON public.mensajealerta USING btree (id_alerta, fecha_hora, id_mensaje);


--
-- TOC entry 3374 (class 1259 OID 16774)
-- Name: idx_recuperacion_clave_usuario; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recuperacion_clave_usuario ON public.recuperacion_clave USING btree (id_usuario, usado);


--
-- TOC entry 3358 (class 1259 OID 16707)
-- Name: idx_ubicacion_alerta_fecha; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ubicacion_alerta_fecha ON public.ubicacion USING btree (id_alerta, fecha_hora DESC, id_ubicacion DESC);


--
-- TOC entry 3357 (class 1259 OID 16595)
-- Name: uq_solicitud_pendiente; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_solicitud_pendiente ON public.solicitudvinculacion USING btree (id_adulto_mayor, id_asistente) WHERE ((estado)::text = 'PENDIENTE'::text);


--
-- TOC entry 3361 (class 1259 OID 16596)
-- Name: uq_usuario_codigo_vinculacion; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_usuario_codigo_vinculacion ON public.usuario USING btree (codigo_vinculacion) WHERE (codigo_vinculacion IS NOT NULL);


--
-- TOC entry 3377 (class 2606 OID 16597)
-- Name: alerta fk_alerta_adulto_mayor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerta
    ADD CONSTRAINT fk_alerta_adulto_mayor FOREIGN KEY (id_adulto_mayor) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3378 (class 2606 OID 16602)
-- Name: alerta fk_alerta_estado_actual; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerta
    ADD CONSTRAINT fk_alerta_estado_actual FOREIGN KEY (id_estado_actual) REFERENCES public.estadoalerta(id_estado);


--
-- TOC entry 3379 (class 2606 OID 16607)
-- Name: alerta fk_alerta_operador; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerta
    ADD CONSTRAINT fk_alerta_operador FOREIGN KEY (id_operador_asignado) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3380 (class 2606 OID 16612)
-- Name: alerta fk_alerta_responsable; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerta
    ADD CONSTRAINT fk_alerta_responsable FOREIGN KEY (id_responsable_atencion) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3381 (class 2606 OID 16617)
-- Name: auditoria fk_auditoria_usuario; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auditoria
    ADD CONSTRAINT fk_auditoria_usuario FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3382 (class 2606 OID 16622)
-- Name: historialalerta fk_historial_alerta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historialalerta
    ADD CONSTRAINT fk_historial_alerta FOREIGN KEY (id_alerta) REFERENCES public.alerta(id_alerta);


--
-- TOC entry 3383 (class 2606 OID 16627)
-- Name: historialalerta fk_historial_estado_anterior; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historialalerta
    ADD CONSTRAINT fk_historial_estado_anterior FOREIGN KEY (id_estado_anterior) REFERENCES public.estadoalerta(id_estado);


--
-- TOC entry 3384 (class 2606 OID 16632)
-- Name: historialalerta fk_historial_estado_nuevo; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historialalerta
    ADD CONSTRAINT fk_historial_estado_nuevo FOREIGN KEY (id_estado_nuevo) REFERENCES public.estadoalerta(id_estado);


--
-- TOC entry 3385 (class 2606 OID 16637)
-- Name: historialalerta fk_historial_usuario_actor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historialalerta
    ADD CONSTRAINT fk_historial_usuario_actor FOREIGN KEY (id_usuario_actor) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3399 (class 2606 OID 16726)
-- Name: mensajealerta fk_mensajealerta_alerta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensajealerta
    ADD CONSTRAINT fk_mensajealerta_alerta FOREIGN KEY (id_alerta) REFERENCES public.alerta(id_alerta);


--
-- TOC entry 3400 (class 2606 OID 16731)
-- Name: mensajealerta fk_mensajealerta_autor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mensajealerta
    ADD CONSTRAINT fk_mensajealerta_autor FOREIGN KEY (id_autor) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3386 (class 2606 OID 16642)
-- Name: notificacion fk_notificacion_alerta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT fk_notificacion_alerta FOREIGN KEY (id_alerta) REFERENCES public.alerta(id_alerta);


--
-- TOC entry 3387 (class 2606 OID 16647)
-- Name: notificacion fk_notificacion_destinatario; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notificacion
    ADD CONSTRAINT fk_notificacion_destinatario FOREIGN KEY (id_destinatario) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3388 (class 2606 OID 16652)
-- Name: parametrosistema fk_parametro_usuario; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parametrosistema
    ADD CONSTRAINT fk_parametro_usuario FOREIGN KEY (id_usuario_actualiza) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3389 (class 2606 OID 16657)
-- Name: redapoyo fk_red_apoyo_adulto_mayor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redapoyo
    ADD CONSTRAINT fk_red_apoyo_adulto_mayor FOREIGN KEY (id_adulto_mayor) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3390 (class 2606 OID 16662)
-- Name: redapoyo fk_red_apoyo_integrante; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.redapoyo
    ADD CONSTRAINT fk_red_apoyo_integrante FOREIGN KEY (id_integrante) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3391 (class 2606 OID 16667)
-- Name: respuestaalerta fk_respuesta_alerta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.respuestaalerta
    ADD CONSTRAINT fk_respuesta_alerta FOREIGN KEY (id_alerta) REFERENCES public.alerta(id_alerta);


--
-- TOC entry 3392 (class 2606 OID 16672)
-- Name: respuestaalerta fk_respuesta_integrante; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.respuestaalerta
    ADD CONSTRAINT fk_respuesta_integrante FOREIGN KEY (id_integrante) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3393 (class 2606 OID 16677)
-- Name: rolpermiso fk_rol_permiso_permiso; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolpermiso
    ADD CONSTRAINT fk_rol_permiso_permiso FOREIGN KEY (id_permiso) REFERENCES public.permiso(id_permiso);


--
-- TOC entry 3394 (class 2606 OID 16682)
-- Name: rolpermiso fk_rol_permiso_rol; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rolpermiso
    ADD CONSTRAINT fk_rol_permiso_rol FOREIGN KEY (id_rol) REFERENCES public.rol(id_rol);


--
-- TOC entry 3397 (class 2606 OID 16687)
-- Name: ubicacion fk_ubicacion_alerta; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ubicacion
    ADD CONSTRAINT fk_ubicacion_alerta FOREIGN KEY (id_alerta) REFERENCES public.alerta(id_alerta);


--
-- TOC entry 3398 (class 2606 OID 16692)
-- Name: usuario fk_usuario_rol; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol) REFERENCES public.rol(id_rol);


--
-- TOC entry 3401 (class 2606 OID 16769)
-- Name: recuperacion_clave recuperacion_clave_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recuperacion_clave
    ADD CONSTRAINT recuperacion_clave_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3395 (class 2606 OID 16697)
-- Name: solicitudvinculacion solicitudvinculacion_id_adulto_mayor_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solicitudvinculacion
    ADD CONSTRAINT solicitudvinculacion_id_adulto_mayor_fkey FOREIGN KEY (id_adulto_mayor) REFERENCES public.usuario(id_usuario);


--
-- TOC entry 3396 (class 2606 OID 16702)
-- Name: solicitudvinculacion solicitudvinculacion_id_asistente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.solicitudvinculacion
    ADD CONSTRAINT solicitudvinculacion_id_asistente_fkey FOREIGN KEY (id_asistente) REFERENCES public.usuario(id_usuario);


-- Completed on 2026-11-21 01:33:07

--
-- PostgreSQL database dump complete
--

\unrestrict ta0nctkbuy5Du9igA8k5GZ9h0t8GLFtlvrT3S7SIWCC2ImnCOOiYcnUiUcwLJKh

